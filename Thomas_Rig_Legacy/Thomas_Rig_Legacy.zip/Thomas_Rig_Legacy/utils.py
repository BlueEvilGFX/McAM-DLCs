import os
import requests
import json
import base64
import math

import bpy
import bmesh

def get_rig():
    scn = bpy.context.scene
    if scn.get('thomas_rig_legacy'):
        if scn.thomas_rig_legacy.get('reference'):
            return scn.thomas_rig_legacy.reference
    return bpy.context.active_object


def is_packed(img):
    try:
        return img.packed_files.values() != []
    except (AttributeError, KeyError, TypeError):
        return False

def safe_unpack(img): #unpacks relative to the file ONLY if the file is saved
    if img.packed_files:
        if bpy.data.is_saved:
            return img.unpack()
        else:
            return img.unpack(method='USE_ORIGINAL')
        

class ThomasRigAddArmor:
    def add_default_armor(self, part):
        rigs_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "armor")
        default_armor_file = os.path.join(rigs_dir, "armor_default.blend")

        # append
        directory = os.path.join(default_armor_file, "Object")
        filepath = os.path.join(directory, part)
        bpy.ops.wm.append(
            filepath=filepath,
            filename=part,
            directory=directory,
            link=False,
            active_collection=True
        )
        
        bpy.ops.object.mode_set(mode = "OBJECT")
        rig = get_rig()
        item = bpy.context.selected_objects[0]
        item.location.x = 0
        item.location.y = 0
        # item.location.z = 0

        # set correct texture
        texture_type = getattr(self, f"{part}_material")
        texture_types = os.path.join(rigs_dir, 'textures')

        material = item.material_slots[0].material
        nodes = material.node_tree.nodes
        texture = os.path.join(texture_types, texture_type+'.png')
        image = bpy.data.images.load(texture)
        nodes['base'].image = image

        # modifiers
        # add armature modifier
        item.modifiers.new(name = "Skeleton", type = "ARMATURE")
        item.modifiers["Skeleton"].object = rig
        # add subdivisions
        item.modifiers.new(name = "subdivision", type = "SUBSURF")
        item.modifiers['subdivision'].show_viewport = False
        item.modifiers['subdivision'].levels = 1
        item.modifiers['subdivision'].render_levels = 3

        # taper lattice
        ThomasRigAddArmor.add_taper(self, item, part)

        # add lattice SmartHead
        if "helmet" in part:
            lattice = rig.children[0].modifiers["Lattice_Smart_Deform"].object
            item.modifiers.new(name = "deform", type = "LATTICE")
            item.modifiers["deform"].object = lattice

            lattice = rig.children[0].modifiers["Lattice_Head"].object
            item.modifiers.new(name = "squash stretch", type = "LATTICE")
            item.modifiers["squash stretch"].object = lattice

            # move to top
            bpy.context.view_layer.objects.active = item
            bpy.ops.object.modifier_move_to_index(modifier="deform", index=0)
            bpy.ops.object.modifier_move_to_index(modifier="squash stretch", index=1)
        else:
            ThomasRigAddDrivers.add_drivers_default_armor(item, rig, part)
        return item

    def add_trims(self, part, item):
        rigs_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "armor")
        trim_textures = os.path.join(rigs_dir, 'textures', 'trims')

        material = item.material_slots[0].material
        nodes = material.node_tree.nodes
        trim_texture = os.path.join(trim_textures, getattr(self, f'{part.split("_")[0]}_trim')+'.png')
        image = bpy.data.images.load(trim_texture)
        nodes['trim'].image = image
        nodes['RGB'].outputs[0].default_value = getattr(self,  f'{part.split("_")[0]}_trim_colour')
        
    def add_custom_armor(self, part):
        rigs_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "armor")
        armor_type = bpy.context.window_manager.thomas_rig_legacy.custom_armor[:-4]
        armor_file = os.path.join(rigs_dir, armor_type  + ".blend")

        # append
        directory = os.path.join(armor_file, "Collection")
        filepath = os.path.join(directory, part)
        bpy.ops.wm.append(filepath=filepath, filename=part,directory=directory,
                        link=False, active_collection=True)
        bpy.ops.object.mode_set(mode = "OBJECT")
        rig = get_rig()
        items = bpy.context.selected_objects

        for idx, item in enumerate(items):
            # add armature modifier
            item.modifiers.new(name = "Skeleton", type = "ARMATURE")
            item.modifiers["Skeleton"].object = rig

            # add subdivisions
            item.modifiers.new(name = "subdivision", type = "SUBSURF")
            item.modifiers['subdivision'].show_viewport = False
            item.modifiers['subdivision'].levels = 1
            item.modifiers['subdivision'].render_levels = 3
            item.modifiers['subdivision'].subdivision_type = "SIMPLE"

            # lattice modifier
            if part == "helmet":
                # scuba does not need head lattice for 2nd helmet part but taper
                if armor_type == 'Scuba' and idx == 1:
                    ThomasRigAddArmor.add_taper(self, item, part)
                    continue
                
                lattice = rig.children[0].modifiers["Lattice_Smart_Deform"].object
                item.modifiers.new(name = "deform", type = "LATTICE")
                item.modifiers["deform"].object = lattice

                lattice = rig.children[0].modifiers["Lattice_Head"].object
                item.modifiers.new(name = "squash stretch", type = "LATTICE")   
                item.modifiers["squash stretch"].object = lattice

                # move to top
                bpy.context.view_layer.objects.active = item
                bpy.ops.object.modifier_move_to_index(modifier="deform", index=0)
                bpy.ops.object.modifier_move_to_index(modifier="squash stretch", index=1)

            if (armor_type in {'Cultist', 'ZombiePlate'}) and "helmet" in part:
                rig.pose.bones["Main_Properties"]["No face"] = True
            elif armor_type in {'Scuba'}:
                # taper lattice
                ThomasRigAddArmor.add_taper(self, item, part)
                ThomasRigAddDrivers.add_drivers_default_armor(item, rig, part)
            elif armor_type == 'Samurai_2' and part == 'leggings' and 'leggings' in item.name:
                ThomasRigAddDrivers.add_drivers_default_armor(item, rig, part)

    def add_taper(self, item, part):
        rig = get_rig()
        if "boots" in part or "leggings" in part:
            # right leg
            lattice = rig.children[0].modifiers["Lattice_R_Leg"].object
            item.modifiers.new(name = "Taper.R", type = "LATTICE")
            item.modifiers["Taper.R"].object = lattice
            item.modifiers["Taper.R"].vertex_group = "Lattice_Right"

            # left leg
            lattice = rig.children[0].modifiers["Lattice_L_Leg"].object
            item.modifiers.new(name = "Taper.L", type = "LATTICE")
            item.modifiers["Taper.L"].object = lattice
            item.modifiers["Taper.L"].vertex_group = "Lattice_Left"

            # move to top
            bpy.context.view_layer.objects.active = item
            bpy.ops.object.modifier_move_to_index(modifier="Taper.R", index=0)
            bpy.ops.object.modifier_move_to_index(modifier="Taper.L", index=1)

            if "leggings" in part:
                lattice = rig.children[0].modifiers["Chest"].object
                item.modifiers.new(name = "Chest", type = "LATTICE")
                item.modifiers["Chest"].object = lattice
                item.modifiers["Chest"].vertex_group = "UpperBodyMain"
                # move to top
                bpy.context.view_layer.objects.active = item
                bpy.ops.object.modifier_move_to_index(modifier="Chest", index=2)

        if "chestplate" in part:
            # chestplate
            lattice = rig.children[0].modifiers["Chest"].object
            item.modifiers.new(name = "Chest", type = "LATTICE")
            item.modifiers["Chest"].object = lattice
            item.modifiers["Chest"].vertex_group = "UpperBodyMain"
            # move to top
            bpy.context.view_layer.objects.active = item
            bpy.ops.object.modifier_move_to_index(modifier="Chest", index=0)
            
        if "helmet_chest_lattice" in item.name:
            # chestplate
            lattice = rig.children[0].modifiers["Chest"].object
            item.modifiers.new(name = "Chest", type = "LATTICE")
            item.modifiers["Chest"].object = lattice
            item.modifiers["Chest"].vertex_group = "UpperBodyMain"
            # move to top
            bpy.context.view_layer.objects.active = item
            bpy.ops.object.modifier_move_to_index(modifier="Chest", index=0)
        return
    

class ThomasRigAddDrivers:
    def add_drivers_default_armor(item, rig, part):
        if part.startswith("chestplate"):
            joint = "arm_elbow"
        elif part.startswith("boots") or part.startswith("leggings"):
            joint = "Leg_knee"
        else:
            return
        ThomasRigAddDrivers.add_driver_bend_120(item, rig, ".R", "Bend.R", joint, "a")
        ThomasRigAddDrivers.add_driver_bend_120(item, rig, ".R", "120.R", joint, "b")
        ThomasRigAddDrivers.add_driver_bend_120(item, rig, ".L", "Bend.L", joint, "a")
        ThomasRigAddDrivers.add_driver_bend_120(item, rig, ".L", "120.L", joint, "b")

    def add_driver_bend_120(item, rig, side, shapeKeyName, boneTarget, ab):
        if ab == "a":
            expression = "tan(value*0.5) if tan(value*0.5) >= 0 else -tan(value*0.5)"
        elif ab == "b":
            expression = "tan(value*0.5)-1 if tan(value*0.5) >= 0 else -tan(value*0.5)-1"

        driver = item.data.shape_keys.key_blocks[shapeKeyName].driver_add("value").driver
        driver.type = "SCRIPTED"

        var = driver.variables.new()
        var.type = "TRANSFORMS"
        var.name = "value"

        driver.variables[0].targets[0].id = rig
        driver.variables[0].targets[0].bone_target = boneTarget + side
        driver.variables[0].targets[0].transform_type = "ROT_X"
        driver.variables[0].targets[0].transform_space = "LOCAL_SPACE"
        driver.expression = expression


class UI_Utils:
    def spacer(layout, factor):
        spacer = layout.row()
        spacer.label(text="")
        spacer.scale_y = factor

    def check_search(display, prop_src, arm_filter=False) -> bool:
        search = get_rig().pose.bones["Misc_Properties"]["search"].lower()
        if arm_filter:
            arm_props = {"L.Arm_FK/IK", "R.Arm_FK/IK", "L.Arm_World", "R.Arm_World"}

            for prop in prop_src.keys():
                if prop in arm_props and search in prop.lower():
                    display.prop(prop_src, f'["{prop}"]', toggle = True)
            return

        for prop in prop_src.keys():
            if(search in prop.lower() and search != ""):
                display.prop(prop_src, f'["{prop}"]', toggle = True)


class SkinDownloader:
    UUID_URL = r"https://api.mojang.com/users/profiles/minecraft/"
    SKIN_URL = r"https://sessionserver.mojang.com/session/minecraft/profile/"

    def __init__(self, player_name, save_location, blender_self) -> None:
        self.player_name = player_name
        self.save_location = save_location
        self.blender_self = blender_self
        self.player_uuid = self.fetch_UUID()
        if self.player_uuid is None:
            self.success = False
            return # player name not found
        self.skin_value = self.fetch_skin_value()
        self.skin_url, self.alex_arms = self.fetch_skin_url()
        self.save_location = self.download_skin()
        self.success = (self.player_uuid is not None and self.save_location is not None)

    def fetch_UUID(self):
        try:
            response = requests.get(self.UUID_URL + self.player_name)
            data = response.json()
            if "errorMessage" in data:
                self.blender_self.report({'ERROR'}, data["errorMessage"])
                return None
            self.player_name = data.get('name')
            return data.get('id')
        except requests.exceptions.RequestException as e:
            self.blender_self.report({'ERROR'}, f"Something went wrong with the reques {e}")

    def fetch_skin_value(self):
        try:
            response = requests.get(self.SKIN_URL + self.player_uuid)
            data = response.json()
            if "errorMessage" in data:
                self.blender_self.report({'ERROR'}, data["errorMessage"])
                return None
            return data.get('properties')[0].get('value')
        except requests.exceptions.RequestException as e:
            self.blender_self.report({'ERROR'}, f"Something went wrong with the reques {e}")

    def fetch_skin_url(self):
        byte_code = base64.b64decode(self.skin_value)
        string_code = str(byte_code, 'utf-8')
        data = json.loads(string_code)
        skin_url = data.get('textures').get('SKIN').get('url')
        alex_arms = data.get('textures').get('SKIN').get('metadata', {}).get('model') == 'slim'
        return skin_url, alex_arms
    
    def download_skin(self):
        try:
            response = requests.get(self.skin_url, stream=True)
            response.raise_for_status()
            save_location = os.path.join(self.save_location, f"{self.player_name}.png")
            with open(save_location, 'wb') as file:
                for chunk in response.iter_content(chunk_size=8192): 
                    file.write(chunk)
            return save_location
        except requests.exceptions.RequestException as e:
            self.blender_self.report({'ERROR'}, f"An error occurred while downloading the skin: {e}")
            return None
        
class ThomasRigBakeArmor:
    def delete_nodes_no_trim(item):
        mat = item.data.materials[0]
        nodes = mat.node_tree.nodes
        keep_nodes = {nodes['Principled BSDF'], nodes['Material Output'], nodes['base']}

        # Remove other nodes
        for node in list(nodes):  # Use list to avoid RuntimeError: Set changed size during iteration
            if node not in keep_nodes:
                nodes.remove(node)
        
        # Connect nodes
        links = mat.node_tree.links
        links.new(nodes['base'].outputs['Color'], nodes['Principled BSDF'].inputs['Base Color'])

        # Move nodes
        nodes['base'].location = (0, 0)
        nodes['Principled BSDF'].location = (400, 0)
        nodes['Material Output'].location = (800, 0)

    def adjust_material(item):
        scn = bpy.context.scene
        mat = item.data.materials[0]
        nodes = mat.node_tree.nodes
        render_engine = scn.render.engine

        # Set up baking settings
        scn.render.engine = 'CYCLES'
        scn.cycles.bake_type = 'DIFFUSE'
        scn.render.bake.use_pass_direct = False
        scn.render.bake.use_pass_indirect = False
        scn.render.bake.use_pass_color = True

        # Create image
        image_name = item.name + '_BakedTexture'
        img = bpy.data.images.new(image_name, 64, 64, alpha=True)

        # Set up baking nodes
        texture_node = nodes.new('ShaderNodeTexImage')
        texture_node.name = 'Bake_Node'
        texture_node.select = True
        texture_node.interpolation = 'Closest'
        nodes.active = texture_node
        texture_node.image = img

        # Bake
        bpy.context.view_layer.objects.active = item
        bpy.ops.object.bake(type='DIFFUSE')

        # Restore original render engine
        scn.render.engine = render_engine

        # Define nodes to keep
        keep_nodes = {texture_node, nodes['Principled BSDF'], nodes['Material Output'], nodes['trim'], nodes['RGB']}

        # Remove other nodes
        for node in list(nodes):  # Use list to avoid RuntimeError: Set changed size during iteration
            if node not in keep_nodes:
                if node.type == 'TEX_IMAGE' and node.image is not None:
                    bpy.data.images.remove(node.image)
                nodes.remove(node)

        # create new colour nodes
        rgb_node = nodes['RGB']

        mix_1_node = nodes.new('ShaderNodeMixRGB')
        mix_1_node.blend_type = 'MULTIPLY'
        mix_1_node.inputs['Fac'].default_value = 1
        mix_1_node.hide = True

        mix_2_node = nodes.new('ShaderNodeMixRGB')
        mix_2_node.hide = True

        # Move nodes
        nodes['Principled BSDF'].location = (640, 0)
        nodes['Material Output'].location = (920, 0)
        nodes['trim'].location = (0, 40)
        rgb_node.location = (0, -260)
        mix_1_node.location = (280, 40)
        mix_2_node.location = (460, 40) 

        # Connect nodes
        links = mat.node_tree.links
        links.new(texture_node.outputs['Color'], mix_2_node.inputs['Color1'])
        links.new(nodes['trim'].outputs['Color'], mix_1_node.inputs['Color1'])
        links.new(nodes['trim'].outputs['Alpha'], mix_2_node.inputs['Fac'])
        links.new(mix_1_node.outputs['Color'], mix_2_node.inputs['Color2'])
        links.new(rgb_node.outputs['Color'], mix_1_node.inputs['Color2'])

        links.new(mix_2_node.outputs['Color'], nodes['Principled BSDF'].inputs['Base Color'])
    
    def add_nodes_leather(item):
        mat = item.data.materials[0]
        nodes = mat.node_tree.nodes

        armor_trim = 'Bake_Node' in nodes

        # create new nodes
        mix_node = nodes.new('ShaderNodeMixRGB')
        mix_node.blend_type = 'MULTIPLY'
        mix_node.inputs['Color2'].default_value = (0.132891, 0.072269, 0.033102, 1)

        colour_ramp = nodes.new('ShaderNodeValToRGB')
        colour_ramp.width = 140
        colour_ramp.color_ramp.interpolation = 'CONSTANT'
        colour_ramp.color_ramp.elements[1].position = 0.1
        colour_ramp.hide = True
        
        # Connect nodes
        texture_node = nodes['Bake_Node'] if armor_trim else nodes['base']
        links = mat.node_tree.links
        links.new(texture_node.outputs['Color'], colour_ramp.inputs['Fac'])
        links.new(colour_ramp.outputs['Color'], mix_node.inputs['Fac'])
        links.new(texture_node.outputs['Color'], mix_node.inputs['Color1'])
        
        if armor_trim: # if armor trim
            links.new(mix_node.outputs['Color'], nodes['Mix (Legacy).001'].inputs['Color1'])
            mix_node.location = (460, 0)
            colour_ramp.location = (280, 0)
        else:
            links.new(mix_node.outputs['Color'], nodes['Principled BSDF'].inputs['Base Color'])
            texture_node.location = (-240, 0)
            colour_ramp.location = (40, 0)
            mix_node.location = (220, 0)

    def remove_alpha_faces(item):
        # Get the object and its mesh data
        mesh = item.data

        # Create a BMesh from the mesh data
        bm = bmesh.new()
        bm.from_mesh(mesh)

        # Get the UV layer
        uv_layer = bm.loops.layers.uv.verify()

        # Get the image
        nodes = item.data.materials[0].node_tree.nodes
        if 'Bake_Node' in nodes:
            image = nodes['Bake_Node'].image
        else:
            image = nodes['base'].image

        # Calculate the width and height
        width, height = image.size

        # Loop through the faces of the BMesh
        for face in bm.faces:
            # For each face, check if any of its vertices have an alpha value of 0 in the UV map
            for loop in face.loops:
                uv_data = loop[uv_layer].uv
                pixel_index = 4 * (int(uv_data[1]*height) * width + int(uv_data[0]*width))
                pixel = image.pixels[pixel_index:pixel_index+4]
                if pixel[3] == 0:  # If the alpha value is 0
                    # If the alpha value is 0, remove the face
                    bmesh.ops.delete(bm, geom=[face], context='FACES')
                    break

        # Update the mesh data with the new BMesh data
        bm.to_mesh(mesh)
        bm.free()

class ThomasRigAddMisc:
    def __init__(self, misc):
        self.misc_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), "misc")
        self.misc = misc
        self.rig = get_rig()

        if misc == "blush" or misc == "blush_1":
            # create blush
            img_path = os.path.join(self.misc_dir , "textures", misc + ".png")
            blush = self.add_image_as_plane(
                img_path = img_path,
                location = (0, -0.3975,2.64),
                rotation = (math.radians(90), 0, 0), 
                ratio = 2/3
                )
            # parent blush
            subdivision = blush.modifiers.new(name = "TEMP", type="SUBSURF") 
            subdivision.levels = 3
            subdivision.subdivision_type = "SIMPLE"
            bpy.ops.object.modifier_apply(modifier="TEMP")
            self.parent_to_head(blush)

        elif misc == "blood_splatter":
            # create blush
            img_path = os.path.join(self.misc_dir , "textures", "blood_splatter.png")
            blush = self.add_image_as_plane(
                img_path = img_path,
                location = (-0.235, -0.3975,2.62),
                rotation = (math.radians(90), math.radians(-90), 0),
                ratio =  1/5
                )
            # parent blush
            subdivision = blush.modifiers.new(name = "TEMP", type="SUBSURF") 
            subdivision.levels = 3
            subdivision.subdivision_type = "SIMPLE"
            bpy.ops.object.modifier_apply(modifier="TEMP")
            self.parent_to_head(blush)
        
        elif misc == "eye_lashes_1" or misc == "eye_lashes_2":
            eye_lashes_file = os.path.join(self.misc_dir , "eye_lashes.blend")

            # append
            directory = os.path.join(eye_lashes_file, "Object")
            filepath = os.path.join(directory, misc)
            bpy.ops.wm.append(
                filepath=filepath,
                filename=misc,
                directory=directory,
                link=False,
                active_collection=True
            )
            eye_lash_R = bpy.context.selected_objects[0]
            eye_lash_R.location = (0, -0.434725, 2.7862) if "1" in misc else (-0.231, -0.4, 2.76756)

            # both lattices for Left and Right
            lattice = self.rig.children[0].modifiers["Lattice_Smart_Deform"].object
            eye_lash_R.modifiers.new(name = "deform", type = "LATTICE")
            eye_lash_R.modifiers["deform"].object = lattice

            lattice = self.rig.children[0].modifiers["Lattice_Head"].object
            eye_lash_R.modifiers.new(name = "squash stretch", type = "LATTICE")
            eye_lash_R.modifiers["squash stretch"].object = lattice

            # duplicating & mirror
            bpy.context.view_layer.objects.active = eye_lash_R
            eye_lash_R.select_set(True)
            bpy.ops.object.duplicate(linked=0,mode='TRANSLATION')
            eye_lash_L = bpy.context.active_object
            bpy.ops.transform.mirror(orient_type="LOCAL", constraint_axis=(True, False, False))

            # lattice eyelash
            lattice = self.rig.children[0].modifiers["Lattice_R.Eyebrow"].object
            eye_lash_R.modifiers.new(name = "eyelash", type = "LATTICE")
            eye_lash_R.modifiers["eyelash"].object = lattice

            lattice = self.rig.children[0].modifiers["Lattice_L.Eyebrow"].object
            eye_lash_L.modifiers.new(name = "eyelash", type = "LATTICE")
            eye_lash_L.modifiers["eyelash"].object = lattice

            # driver
            if "1" in misc:
                eye_lash_L.location[0] = -0.008
                self.eye_lash_driver(eye_lash_R, "iUI_Blink.r")
                self.eye_lash_driver(eye_lash_L, "iUI_Blink.L")
            else:
                eye_lash_L.location[0] = 0.231

        # select only the rigs
        bpy.ops.object.select_all (action='DESELECT')
        self.rig.select_set(True)
        bpy.context.view_layer.objects.active = self.rig
        bpy.context.view_layer.update()
        self.rig.location = self.rig.location

    def eye_lash_driver(self, item, bone):
        driver = item.data.shape_keys.key_blocks["UP"].driver_add("value").driver
        driver.type = "SCRIPTED"

        var = driver.variables.new()
        var.type = "TRANSFORMS"
        var.name = "location"

        driver.variables[0].targets[0].id = self.rig
        driver.variables[0].targets[0].bone_target = bone
        driver.variables[0].targets[0].transform_type = "LOC_Y"
        driver.variables[0].targets[0].transform_space = "LOCAL_SPACE"
        driver.expression = "-location / 0.0525"

    def add_image_as_plane(self, img_path, location=(0,0,0), rotation=(0,0,0), ratio=1) -> bpy.types.Object:
        img = bpy.data.images.load(img_path)

        bpy.ops.mesh.primitive_plane_add(
            size=1,
            location=location,
            rotation=rotation
        )
        plane = bpy.context.object
        plane.name = self.misc
        plane.scale.x = img.size[0] / max(img.size) * ratio
        plane.scale.y = img.size[1] / max(img.size) * ratio

        # create material
        material = bpy.data.materials.new(name=self.misc)
        material.use_nodes = True
        material.blend_method = "BLEND"
        plane.data.materials.append(material)

        nodes = material.node_tree.nodes

        img_node = nodes.new("ShaderNodeTexImage")
        img_node.location = (-400, 300)
        img_node.interpolation = "Closest"
        img_node.image = img

        links = material.node_tree.links
        links.new(img_node.outputs['Color'], nodes['Principled BSDF'].inputs['Base Color'])
        links.new(img_node.outputs['Alpha'], nodes['Principled BSDF'].inputs['Alpha'])
        return plane

    def parent_to_head(self, obj):
        child_of = obj.constraints.new(type="CHILD_OF")
        child_of.target = self.rig
        child_of.subtarget = "Head"

        lattice = self.rig.children[0].modifiers["Lattice_Smart_Deform"].object
        obj.modifiers.new(name = "deform", type = "LATTICE")
        obj.modifiers["deform"].object = lattice

        lattice = self.rig.children[0].modifiers["Lattice_Head"].object
        obj.modifiers.new(name = "squash stretch", type = "LATTICE")   
        obj.modifiers["squash stretch"].object = lattice