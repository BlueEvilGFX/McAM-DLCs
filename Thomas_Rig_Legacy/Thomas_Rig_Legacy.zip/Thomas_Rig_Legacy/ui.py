import bpy
from . import utils
from MC_Assets_Manager.core.utils import icons

def draw(self, context):
    layout = self.layout
    scn = context.scene
    rig = utils.get_rig()

    main_props  = rig.pose.bones["Main_Properties"]
    misc_props  = rig.pose.bones["Misc_Properties"]
    r_arm_props = rig.pose.bones["R.Arm_Properties"]
    l_arm_props = rig.pose.bones["L.Arm_Properties"]
    r_leg_props = rig.pose.bones["R.Leg_Properties"]
    l_leg_props = rig.pose.bones["L.Leg_Properties"]
    pupil_props = rig.pose.bones["Pupils_controller"]

    # search function
    layout.prop(misc_props, '["search"]')
    if misc_props["search"] != "":
        column = layout.box().column()
        utils.UI_Utils.check_search(column, main_props)
        utils.UI_Utils.check_search(column, r_arm_props, True)
        utils.UI_Utils.check_search(column, l_arm_props, True)
        utils.UI_Utils.check_search(column, r_leg_props)
        utils.UI_Utils.check_search(column, l_leg_props)
        utils.UI_Utils.check_search(column, pupil_props)
        return
    
    # AntiLag
    row = layout.row()
    row.prop(main_props, '["AntiLag"]', toggle = True)
    render = bpy.context.scene.render
    row = row.row(align=True)
    row.prop(render, "use_simplify", toggle = True, text = "simplify")
    row = row.row(align = True)
    row.enabled = render.use_simplify
    row.prop(render, "simplify_subdivision", text="")

    # normal UI
    header = layout.row(align=True)
    header.scale_y = 1.2
    tab = rig.pose.bones["Main_Properties"]["Settings_Tab"]
    tabs = {0 : "Design", 1 : "Material", 2 : "Posing"}

    col = layout.box().column()

    # !!! 
    for i in range(3):
        r = header.row(align=True)
        r.alert = (tab == i)
        o = r.operator("thomasriglegacy.change_setting_tab", text = tabs.get(i))
        o.tab = i

    # design tab
    if tab == 0:
        # misc design
        col.prop(main_props, '["Second layer"]', toggle = True, text = "2nd Layer")
        col.prop(main_props, '["Smooth bends"]', toggle = True, text = "Smooth Bends")

        # neck
        row = col.row(align = True)
        row.prop(main_props, '["neck"]', toggle = True, text = "Neck")
        row = row.split(align = True)
        row.enabled = main_props["neck"]
        row.prop(main_props, '["neck_bendy"]', toggle = True, text = "Bendy")

        # head
        icon = "CHECKBOX_HLT" if main_props["No face"] else "CHECKBOX_DEHLT"
        col.prop(main_props, '["No face"]', toggle = True, text = "No Face", icon = icon)
        c_head = col.column(align = True)
        c_head.enabled = not main_props["No face"]
        row = c_head.row(align = True)
        row.label(icon = "BLANK1")
        row.scale_x = 0.5
        row.prop(main_props, '["Texture deform"]', toggle = True, text = "Texture Deform")
        row = c_head.row(align = True)
        row.label(icon = "BLANK1")
        row.scale_x = 0.5
        row.prop(main_props, '["Eyebrow thickness"]', text = "Brow Height")
        utils.UI_Utils.spacer(col, factor = 0.3)

        # arms
        row = col.row(align=True)
        row.prop(main_props, '["Slim main"]', toggle = True, text = "Slim Arms")
        arms = row.row(align = True)
        arms.enabled = main_props["Slim main"]
        arms.prop(main_props, '["3x3"]', toggle = True, text = "3x3")

        # fingers
        row = col.row(align = True)
        row.prop(main_props, '["Finger main"]', toggle = True, text = "", icon = "VIEW_PAN")
        row = row.split(align = True)
        row.enabled = main_props["Finger main"]
        row.prop(main_props, '["Finger+ main"]', toggle = True, text = "Finger+")

        # deforms
        box = layout.box()
        col = box.column()
        icon = "DOWNARROW_HLT" if misc_props["Mesh_Deforms"] else "RIGHTARROW"
        col.prop(misc_props, '["Mesh_Deforms"]', toggle = True, text = "Female Deforms", icon = icon)
        if misc_props["Mesh_Deforms"]:
            row = col.row(align = True)
            row.label(icon = "BLANK1")
            row.scale_x = 0.5
            col = row.column()
            col.prop(misc_props, '["Leg_Taper"]', toggle = True, text = "Leg Taper", slider = True)
            waist_lattice = rig.children[0].modifiers["Chest"].object
            col.prop(waist_lattice.data.shape_keys.key_blocks["Breast"], "value", text = "Breast")
            col.prop(waist_lattice.data.shape_keys.key_blocks["Waist"], "value", text = "Waist")

        # new assets
        col = layout.column()
        utils.UI_Utils.spacer(col, factor = 0.3)
        split = col.row(align=True)
        left = split.box().column()
        right = split.box().column()

        pcoll = icons.mcam_icons[icons.PCOLL_DLC_ID]
        sub_tab =rig.pose.bones["Main_Properties"]["Assets_Tab"]
        sub_tabs = {
            0 : pcoll["Thomas_Rig_Legacy:armor"].icon_id,
            1 : pcoll["Thomas_Rig_Legacy:cape"].icon_id,
            2 : pcoll["Thomas_Rig_Legacy:elytra"].icon_id,
            3 : pcoll["Thomas_Rig_Legacy:glow_item_frame"].icon_id
        }

        for i in range(len(sub_tabs)):
            r = left.row()
            r.alert = (sub_tab == i)
            r.operator("thomasriglegacy.change_armor_tab", text = "", icon_value = sub_tabs.get(i)).tab = i
        
        # armor
        if main_props['Assets_Tab'] == 0:
            col = right.column()
            col.operator("thomasriglegacy.addarmor", text = "Armor", icon = "ADD")
            col.operator("thomasriglegacy.parenttool", text = "Parent", icon = "CON_CHILDOF")
            # space
            col.label(text="")
            col.label(text="")

        # cape
        if main_props['Assets_Tab'] == 1:
            row = right.row(align = True)
            row.label(text="Cape")
            row.operator("thomasriglegacy.appendcape", text = "", icon = "ADD")
            row.operator("thomasriglegacy.removecape", text = "", icon = "REMOVE")

            if misc_props['cape']:
                try:
                    img_node = misc_props['cape'].objects[2].material_slots[0].material.node_tree.nodes['Image Texture'].image
                    left = right.row(align = True)
                    left.operator("thomasriglegacy.imgpack" , text="",
                                icon="PACKAGE" if utils.is_packed(img_node) else "UGLYPACKAGE"
                        ).id_name = img_node.name 

                    main = left.row(align=True) 
                    main.enabled = not utils.is_packed(img_node)
                    main.prop(img_node, "filepath", text="")  
                    main.operator("thomasriglegacy.imgreload", text = "", icon = "FILE_REFRESH"
                        ).id_name = img_node.name
                except:
                    row = right.row()
                    row.scale_y = 0.67
                    row.label(text="material error", icon = "ERROR")
                row = right.row(align = True)
                row.scale_x = 10
                row.prop(misc_props['cape'], "hide_viewport", text="")
                row.prop(misc_props['cape'], "hide_render", text="")
            else:
                # space
                right.label(text="")
                right.label(text="")
                right.label(text="")

        # elytra
        if main_props['Assets_Tab'] == 2:
            row = right.row(align = True)
            row.label(text="Elytra")
            row.operator("thomasriglegacy.appendelytra", text = "", icon = "ADD")
            row.operator("thomasriglegacy.removeelytra", text = "", icon = "REMOVE")

            if misc_props['elytra']:
                try:
                    img_node = misc_props['elytra'].objects[0].material_slots[0].material.node_tree.nodes['Image Texture'].image
                    left = right.row(align = True)
                    left.operator("thomasriglegacy.imgpack" , text="",
                                icon="PACKAGE" if utils.is_packed(img_node) else "UGLYPACKAGE"
                        ).id_name = img_node.name 

                    main = left.row(align=True) 
                    main.enabled = not utils.is_packed(img_node)
                    main.prop(img_node, "filepath", text="")  
                    main.operator("thomasriglegacy.imgreload", text = "", icon = "FILE_REFRESH"
                        ).id_name = img_node.name
                except:
                    row = right.row()
                    row.scale_y = 0.67
                    row.label(text="material error", icon = "ERROR")
                row = right.row(align = True)
                row.scale_x = 10
                row.prop(misc_props['elytra'], "hide_viewport", text="")
                row.prop(misc_props['elytra'], "hide_render", text="")
            else:
                # space
                right.label(text="")
                right.label(text="")
                right.label(text="")
        
        # miscs
        if main_props['Assets_Tab'] == 3:
            col = right.column()
            enum = col.row()
            enum.scale_y = 0.54
            th_prev = context.window_manager.thomas_rig_legacy
            enum.template_icon_view(th_prev, "misc")
            col.operator("thomasriglegacy.appendmisc", icon="ADD", text = f'<{th_prev.misc[:-4]}>')

    # materials tab
    if tab == 1:
        mat_obj = rig.children[0]
        
        # skin
        try:
            img = mat_obj.material_slots[0].material.node_tree.nodes['Skin'].image

            left = col.row(align = True)  
            left.operator("thomasriglegacy.imgpack" , text="",
                        icon="PACKAGE" if utils.is_packed(img) else "UGLYPACKAGE"
                ).id_name = img.name 

            main = left.row(align=True) 
            main.enabled = not utils.is_packed(img)
            main.prop(img, "filepath", text="")  
            main.operator("thomasriglegacy.imgreload", text = "", icon = "FILE_REFRESH"
                ).id_name = img.name
            main.operator("thomasriglegacy.downloadskin", icon = 'SORT_ASC')
        except:
            col.label(text="material error", icon = "ERROR")

        # eyes
        try:
            eye_node = mat_obj.material_slots[1].material.node_tree.nodes['Eyes'].inputs
            
            col = layout.box().column()
            row = col.row(align = True)
            row.label(text = "Eye Type:")
            # row.prop(eye_node["Type"], "default_value", text = "")
            row.prop(main_props, '["Eye type"]', text = "")
            row.prop(main_props, '["Different eyes colour"]', toggle = True, text = "", icon = "PHYSICS")

            settings = col.row()
            # eye_type = eye_node["Type"].default_value
            eye_type = rig.pose.bones["Main_Properties"]["Eye type"]
            two_colour = rig.pose.bones["Main_Properties"]["Different eyes colour"]

            # eye type texture
            if eye_type == 2:
                # settings.prop(eye_node["TextureType"], "default_value", text = "texture type")
                settings.prop(main_props, '["Eye texture type"]', text = "texture type")

            utils.UI_Utils.spacer(col, factor = 0.3)
            colour = col.row()

            # eye type solid
            if eye_type != 1:
                colour = col.row()
                colour.prop(eye_node["1_EyeSC"], "default_value", text = "")
                if two_colour:
                    colour.prop(eye_node["2_EyeSC"], "default_value", text = "")

            # eye type original 
            if eye_type == 1:
                main = colour.row()

                a = main.row(align = True)
                c = a.column(align = True)
                c.prop(eye_node["1_Color1"], "default_value", text = "")
                c.prop(eye_node["1_Color2"], "default_value", text = "")

                c = a.column(align = True)
                c.prop(eye_node["1_Reflection"], "default_value", text = "")
                c.prop(eye_node["1_Pupil"], "default_value", text = "")

                if two_colour:
                    second = main.split()
                    a = second.row(align = True)
                    c = a.column(align = True)
                    c.prop(eye_node["2_Color1"], "default_value", text = "")
                    c.prop(eye_node["2_Color2"], "default_value", text = "")

                    c = a.column(align = True)
                    c.prop(eye_node["2_Reflection"], "default_value", text = "")
                    c.prop(eye_node["2_Pupil"], "default_value", text = "")
                
                row = col.row()
                row.prop(eye_node["1_RimSize"], "default_value", text = "Rim Size")
                if two_colour:
                    row.prop(eye_node["2_RimSize"], "default_value", text = "Rim Size")

            utils.UI_Utils.spacer(col, factor = 0.3)
            
            col.prop(eye_node["Roughness"], "default_value", text = "Roughness")
        except:
            col.label(text="eye material not found", icon="ERROR")

        try:
            # eyebrow
            eyebrow_node = mat_obj.material_slots[2].material.node_tree.nodes['Mix'].inputs
            row = layout.box().row(align = True)
            row.prop(main_props, '["CC eyebrow"]', toggle = True, text = "Eyebrow")
            split = row.split(align = True)
            split.enabled = main_props["CC eyebrow"]
            split.prop(eyebrow_node[7], "default_value", text = "")
        except:
            col.label(text="eyebrow material not found", icon="ERROR")


    # posing tab
    if tab == 2:
        col.prop(rig, "show_in_front", toggle = True)

        box = layout.box()
        col = box.column()

        # arms/legs
        split = col.split(factor=3/11)
        left = split.column()
        right = split.column()

        # arms
        left.label(text="Arm IK")
        Arms = right.row()
        # left
        arms = Arms.row(align=True)
        arms.prop(l_arm_props, '["L.Arm_FK/IK"]', toggle = True, text = "L")
        l = arms.split(align=True)
        l.enabled = l_arm_props["L.Arm_FK/IK"]
        l.prop(rig.pose.bones["L.arm_stretch"].constraints["Stretch To"], "enabled",  text ="", icon = "CON_STRETCHTO", invert_checkbox = True)
        l.prop(l_arm_props, '["L.Arm_World"]', toggle = True, text = "", icon = "WORLD")
        # right
        arms = Arms.row(align=True)
        arms.prop(r_arm_props, '["R.Arm_FK/IK"]', toggle = True, text = "R")
        r = arms.split(align=True)
        r.enabled = r_arm_props["R.Arm_FK/IK"]
        r.prop(rig.pose.bones["R.arm_stretch"].constraints["Stretch To"], "enabled", text ="", icon = "CON_STRETCHTO", invert_checkbox = True)
        r.prop(r_arm_props, '["R.Arm_World"]', toggle = True, text = "", icon = "WORLD")

        # legs
        left.label(text="Leg IK")
        Legs = right.row()
        # left
        legs = Legs.row(align=True)
        legs.prop(l_leg_props, '["L.IK/FK"]', toggle = True, text = "L")
        l = legs.split(align=True)
        l.enabled = not l_leg_props["L.IK/FK"]
        l.prop(rig.pose.bones["Leg.L"].constraints["Stretch To"], "enabled", text ="", icon = "CON_STRETCHTO", invert_checkbox = True, toggle = True)
        # mid
        mid = Legs.row()
        mid.enabled = not (r_leg_props["R.IK/FK"] or l_leg_props["L.IK/FK"])
        mid.prop(main_props, '["Leg body deform"]', toggle = True, icon = "CONSTRAINT_BONE", text = "")
        # right
        legs = Legs.row(align=True)
        legs.prop(r_leg_props, '["R.IK/FK"]', toggle = True, text = "R")
        r = legs.split(align=True)
        r.enabled = not r_leg_props["R.IK/FK"]
        r.prop(rig.pose.bones["Leg.R"].constraints["Stretch To"], "enabled", text ="", icon = "CON_STRETCHTO", invert_checkbox = True, toggle = True)

        utils.UI_Utils.spacer(col, factor = 0.3)
        col.prop(main_props, '["Full rigged face"]', toggle = True, text = "Full rigged face")

        utils.UI_Utils.spacer(col, factor = 0.3)
        col.prop(main_props, '["Head world"]', toggle = True, text = "Head World")

        # eyes
        row = col.row(align = True)
        row.enabled = main_props["Head world"]
        row.prop(main_props, '["Eyes tracker"]', toggle = True, text = "Eyes Tracker")
        r = row.row(align = True)
        r.enabled = main_props["Eyes tracker"]
        r.prop(pupil_props, '["Easy look head"]', icon = "MONKEY", text = "")
        r.prop(pupil_props, '["Easy look mouth"]', icon = "MOD_SIMPLIFY", text = "")
        r.prop(pupil_props, '["Easy look upper body"]', icon = "MATCLOTH", text = "")
        col.prop(main_props, '["Eyes follow"]', toggle = True, text = "Eyes Follow")

        # smart deform
        row = col.row(align = True)
        row.prop(main_props, '["Smart deform"]', toggle = True, text = "Smart Deform")
        r = row.row(align = True)
        r.enabled = main_props["Smart deform"]
        r.prop(main_props, '["Smart deform strength"]', text = "")
        r.prop(main_props, '["Bone shape smart deform"]', toggle = True, text = "", icon = "BONE_DATA")

        utils.UI_Utils.spacer(col, 0.3)
        col.prop(main_props, '["Flip bone"]', toggle = True, text = "Flip Bone")

        # finger
        col = layout.box().column()
        row = col.row(align = True)
        row.prop(main_props, '["Finger main"]', toggle = True, text = "", icon = "VIEW_PAN")
        row = row.split(align = True)
        row.enabled = main_props["Finger main"]
        row.prop(main_props, '["Finger+ main"]', toggle = True, text = "Finger+")