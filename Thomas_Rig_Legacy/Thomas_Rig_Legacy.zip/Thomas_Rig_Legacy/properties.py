import os
import bpy
from bpy.types import PropertyGroup
from bpy.types import WindowManager

RIG_ID = 'Thomas_Rig_Legacy'

preview_collections = {}

class SceneProperty(PropertyGroup):
    def update_reference(self, context):
        if context.scene.thomas_rig_legacy.reference == None:
            return
        if context.scene.thomas_rig_legacy.reference.get("Rig_ID") != RIG_ID:
            context.scene.thomas_rig_legacy.reference = None

    def update_reference_toggle(self, context):
        if context.scene.thomas_rig_legacy.reference_toggle:
            bpy.app.handlers.depsgraph_update_post.append(thomas_rig_reference_handler)
        else:
            bpy.app.handlers.depsgraph_update_post.remove(thomas_rig_reference_handler)

    reference : bpy.props.PointerProperty(type=bpy.types.Object, update = update_reference) # type: ignore
    reference_toggle : bpy.props.BoolProperty(default=True, update=update_reference_toggle) # type: ignore


class PreviewsProperty(PropertyGroup):
    def callback_base(self, context, directory, entry):
        enum_items = []

        if context is None:
            return enum_items
        
        pcoll = preview_collections['thomas_rig_legacy']
        
        if directory and os.path.exists(directory):
            image_paths = [fn for fn in os.listdir(directory) if fn.lower().endswith('.png')]

            for i, name in enumerate(image_paths):
                filepath = os.path.join(directory, name)

                thumb = pcoll.get(name)
                if not thumb:
                    thumb = pcoll.load(name, filepath, 'IMAGE')
                    
                enum_items.append((name, name, '', thumb.icon_id, i))

        setattr(pcoll, entry, enum_items)
        return enum_items
    
    def callback_custom_armor(self, context):
        directory = os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            "armor",
            "Custom_Armor_Previews"
            )
        return self.callback_base(context, directory, "custom_armor")

    def callback_misc(self, context):
        directory = os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            "misc",
            "previews"
            )
        return self.callback_base(context, directory, "misc")


    custom_armor : bpy.props.EnumProperty(items = callback_custom_armor) # type: ignore
    misc : bpy.props.EnumProperty(items=callback_misc) # type: ignore

def thomas_rig_reference_handler(scene):
    try:
        if (bpy.context.active_object.get('Rig_ID') == RIG_ID):
            scene.thomas_rig_legacy.reference = bpy.context.active_object
    except:
        pass


def register():
    bpy.utils.register_class(SceneProperty)
    bpy.utils.register_class(PreviewsProperty)

    bpy.types.Scene.thomas_rig_legacy = bpy.props.PointerProperty(type=SceneProperty)
    WindowManager.thomas_rig_legacy = bpy.props.PointerProperty(type=PreviewsProperty)

    pcoll = bpy.utils.previews.new()
    pcoll.custom_armor = ()
    preview_collections['thomas_rig_legacy'] = pcoll

    bpy.app.handlers.depsgraph_update_post.append(thomas_rig_reference_handler)
    bpy.context.scene.thomas_rig_legacy.reference_toggle = True

def unregister():
    if thomas_rig_reference_handler in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(thomas_rig_reference_handler)

    del WindowManager.thomas_rig_legacy
    del bpy.types.Scene.thomas_rig_legacy

    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    preview_collections.clear()

    bpy.utils.unregister_class(PreviewsProperty)
    bpy.utils.unregister_class(SceneProperty) 