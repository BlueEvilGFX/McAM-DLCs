import bpy
from bpy.types import PropertyGroup

from . import utils
from . import operators
from . import properties

from MC_Assets_Manager.core.utils import icons

RIG_ID = 'Thomas_Rig_Legacy'

class PreferencesProperty(PropertyGroup):
    pass

class CustomAddonPreferences():
    '''Creates a Panel in the User Preferences -> Addon Preferences'''

    def display(self, element=None):
        pass


class THOMASRIGLEGACY_OT_PANEL(bpy.types.Panel):
    bl_label = "Thomas Rig Legacy"
    bl_idname = "SCENE_PT_THOMAS_RIG_LEGACY"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Thomas Rig Legacy"

    def draw(self, context):
        pcoll = icons.mcam_icons[icons.PCOLL_DLC_ID]
        icon = pcoll["Thomas_Rig_Legacy:automatic"].icon_id
        row = self.layout.row(align=True)
        row.prop(bpy.context.scene.thomas_rig_legacy, 'reference', text = "")
        row.prop(bpy.context.scene.thomas_rig_legacy, 'reference_toggle',toggle=True, text="", icon_value = icon)

        rig = utils.get_rig()
        if not rig.get("Rig_ID") == RIG_ID:
            self.layout.label(text="Thomas Rig Legacy is not selected")
            return

        from . import ui
        ui.draw(self, context)
        

def register():
    properties.register()
    operators.register()
    bpy.utils.register_class(THOMASRIGLEGACY_OT_PANEL)

def unregister():
    bpy.utils.unregister_class(THOMASRIGLEGACY_OT_PANEL)
    operators.unregister()
    properties.unregister()