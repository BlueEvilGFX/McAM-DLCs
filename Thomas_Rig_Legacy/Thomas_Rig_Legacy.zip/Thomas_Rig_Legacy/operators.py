import os

import bpy
from bpy.props import IntProperty
from bpy.types import Context, Operator
from MC_Assets_Manager.core.utils import icons

from . import utils


class THOMAS_RIG_TAB_OT_SET(Operator):
    """
    description:
        operator which changes the Settings_Tab int -> mimic enum property
    args:
        asset_type : design | materials | posing
    """
    bl_idname = "thomasriglegacy.change_setting_tab"
    bl_label = "change setting tab to $()"

    tab : IntProperty() # type: ignore

    def execute(self, context):
        rig = utils.get_rig()
        rig.pose.bones["Main_Properties"]["Settings_Tab"] = self.tab
        return{'FINISHED'}
    

class THOMAS_RIG_ASSETS_ARMOR_TAB_OT_SET(Operator):
    """
    description:
        operator which changes the assets_tab int -> mimic enum property
    args:
        asset_type : armor | cape | elytra
    """
    bl_idname = "thomasriglegacy.change_armor_tab"
    bl_label = "change setting tab to $()"

    tab : IntProperty() # type: ignore

    def execute(self, context):
        rig = utils.get_rig()
        rig.pose.bones["Main_Properties"]["Assets_Tab"] = self.tab
        return{'FINISHED'}


class THOMAS_RIG_IMG_PACK(Operator):
    bl_idname = "thomasriglegacy.imgpack"
    bl_label = ""
    bl_description = "Pack/Unpack the skin texture"

    id_name: bpy.props.StringProperty() # type: ignore

    @classmethod
    def poll(cls, context):
        rig = utils.get_rig()
        return rig is not None

    def execute(self, context):
        img = bpy.data.images[self.id_name]
        if utils.is_packed(img):
            utils.safe_unpack(img)
        else:
            img.pack()
        return {'FINISHED'}
    

class THOMAS_RIG_SKIN_DOWNLOAD(Operator):
    bl_idname = "thomasriglegacy.downloadskin"
    bl_label = ""
    bl_description = "donwloads the minecraft skin by user name"

    user_name : bpy.props.StringProperty() # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Please enter the username from which you want to get the skin.", icon='FILE_TEXT')
        layout.prop(self, 'user_name')
   
    def execute(self, context):
        skin_directory_path = os.path.join(os.path.dirname(__file__), 'rigs', 'skins')
        if not os.path.exists(skin_directory_path):
            os.mkdir(skin_directory_path)
        
        downloder = utils.SkinDownloader(self.user_name, skin_directory_path, self)
        if downloder.success:
            rig = utils.get_rig()
            bpy.context.view_layer.objects.active = rig
            mat_obj = rig.children[0]
            mat = mat_obj.material_slots[0].material
            skin_img = mat.node_tree.nodes['Skin'].image
            skin_img.filepath = downloder.save_location

            mode = rig.mode
            if mode != 'POSE':
                bpy.ops.object.mode_set(mode='POSE')
            rig.pose.bones["Main_Properties"]["Slim main"] = downloder.alex_arms
            bpy.ops.object.mode_set(mode=mode)
            bpy.context.object.update_tag()
            self.report({'INFO'}, 'Skin has been downloaded and changed!')
            return {'FINISHED'}
        else:
            return {'CANCELLED'}

class THOMAS_RIG_IMAGERELOAD(Operator):
    bl_idname = "thomasriglegacy.imgreload"
    bl_label = ""
    bl_description = "reload the skin texture"

    id_name: bpy.props.StringProperty() # type: ignore

    @classmethod
    def poll(cls, context):
        rig = utils.get_rig()
        return rig is not None

    def execute(self, context):
        img = bpy.data.images[self.id_name]
        img.reload()
        return {'FINISHED'}


class THOMAS_RIG_ARMOR_ADD(Operator):
    bl_idname = "thomasriglegacy.addarmor"
    bl_label = "add armor"
    bl_options = {'REGISTER', 'UNDO'}

    helmet : bpy.props.BoolProperty() # type: ignore
    chestplate : bpy.props.BoolProperty() # type: ignore
    leggings : bpy.props.BoolProperty() # type: ignore
    boots : bpy.props.BoolProperty() # type: ignore

    armor_parts = ["helmet", "chestplate", "leggings", "boots"]

    # armor select
    armor_type : bpy.props.EnumProperty(
        default = 'default',
        items = [
            ('default', 'default', ''),
            ('custom', 'custom', '')
        ]
    ) # type: ignore

    # custom armor
    armor_custom_type : bpy.props.EnumProperty(
        name = "material",
        default = 'samurai',
        items = [
            ('samurai', 'samurai', ''),
            ('cultist', 'cultist', ''),
            ('zombiePlate', 'zombiePlate', '')
        ]
    ) # type: ignore

    # default armor
    helmet_material : bpy.props.EnumProperty(
        name = "",
        default = 'diamond',
        items = [
            ('leather', 'leather', ''),
            ('chainmail', 'chainmail', ''),
            ('iron', 'iron', ''),
            ('gold', 'gold', ''),
            ('diamond', 'diamond', ''),
            ('netherite', 'netherite', '')
        ]
    ) # type: ignore

    chestplate_material : bpy.props.EnumProperty(
        name = "",
        default = 'diamond',
        items = [
            ('leather', 'leather', ''),
            ('chainmail', 'chainmail', ''),
            ('iron', 'iron', ''),
            ('gold', 'gold', ''),
            ('diamond', 'diamond', ''),
            ('netherite', 'netherite', '')
        ]
    ) # type: ignore
    
    leggings_material : bpy.props.EnumProperty(
        name = "",
        default = 'diamond',
        items = [
            ('leather', 'leather', ''),
            ('chainmail', 'chainmail', ''),
            ('iron', 'iron', ''),
            ('gold', 'gold', ''),
            ('diamond', 'diamond', ''),
            ('netherite', 'netherite', '')
        ]
    ) # type: ignore

    boots_material : bpy.props.EnumProperty(
        name = "",
        default = 'diamond',
        items = [
            ('leather', 'leather', ''),
            ('chainmail', 'chainmail', ''),
            ('iron', 'iron', ''),
            ('gold', 'gold', ''),
            ('diamond', 'diamond', ''),
            ('netherite', 'netherite', '')
        ]
    ) # type: ignore
    
    # armor trims
    helmet_trim : bpy.props.EnumProperty(
        name = '',
        default = 'None',
        items = [
            ('None', 'None', ''),
            ('coast', 'coast' , ''),
            ('dune', 'dune' , ''),
            ('eye', 'eye' , ''),
            ('host', 'host' , ''),
            ('raiser', 'raiser' , ''),
            ('rib', 'rib' , ''),
            ('sentry', 'sentry' , ''),
            ('shaper', 'shaper' , ''),
            ('silence', 'silence' , ''),
            ('snout', 'snout' , ''),
            ('spire', 'spire' , ''),
            ('tide', 'tide' , ''),
            ('vex', 'vex' , ''),
            ('ward', 'ward' , ''),
            ('wayfinder', 'wayfinder' , ''),
            ('wild', 'wild' , '')
        ]
    ) # type: ignore

    chestplate_trim : bpy.props.EnumProperty(
        name = '',
        default = 'None',
        items = [
            ('None', 'None', ''),
            ('coast', 'coast' , ''),
            ('dune', 'dune' , ''),
            ('eye', 'eye' , ''),
            ('host', 'host' , ''),
            ('raiser', 'raiser' , ''),
            ('rib', 'rib' , ''),
            ('sentry', 'sentry' , ''),
            ('shaper', 'shaper' , ''),
            ('silence', 'silence' , ''),
            ('snout', 'snout' , ''),
            ('spire', 'spire' , ''),
            ('tide', 'tide' , ''),
            ('vex', 'vex' , ''),
            ('ward', 'ward' , ''),
            ('wayfinder', 'wayfinder' , ''),
            ('wild', 'wild' , '')
        ]
    ) # type: ignore

    leggings_trim : bpy.props.EnumProperty(
        name = '',
        default = 'None',
        items = [
            ('None', 'None', ''),
            ('coast', 'coast' , ''),
            ('dune', 'dune' , ''),
            ('eye', 'eye' , ''),
            ('host', 'host' , ''),
            ('raiser', 'raiser' , ''),
            ('rib', 'rib' , ''),
            ('sentry', 'sentry' , ''),
            ('shaper', 'shaper' , ''),
            ('silence', 'silence' , ''),
            ('snout', 'snout' , ''),
            ('spire', 'spire' , ''),
            ('tide', 'tide' , ''),
            ('vex', 'vex' , ''),
            ('ward', 'ward' , ''),
            ('wayfinder', 'wayfinder' , ''),
            ('wild', 'wild' , '')
        ]
    ) # type: ignore

    boots_trim : bpy.props.EnumProperty(
        name = '',
        default = 'None',
        items = [
            ('None', 'None', ''),
            ('coast', 'coast' , ''),
            ('dune', 'dune' , ''),
            ('eye', 'eye' , ''),
            ('host', 'host' , ''),
            ('raiser', 'raiser' , ''),
            ('rib', 'rib' , ''),
            ('sentry', 'sentry' , ''),
            ('shaper', 'shaper' , ''),
            ('silence', 'silence' , ''),
            ('snout', 'snout' , ''),
            ('spire', 'spire' , ''),
            ('tide', 'tide' , ''),
            ('vex', 'vex' , ''),
            ('ward', 'ward' , ''),
            ('wayfinder', 'wayfinder' , ''),
            ('wild', 'wild' , '')
        ]
    ) # type: ignore

    # armor trims colour
    helmet_trim_colour : bpy.props.FloatVectorProperty(
        name="", 
        subtype='COLOR', 
        size = 4,
        default=[1, 1, 1, 1],
        max = 1,
        min = 0,
    ) # type: ignore

    chestplate_trim_colour : bpy.props.FloatVectorProperty(
        name="", 
        subtype='COLOR', 
        size = 4,
        default=[1, 1, 1, 1],
        max = 1,
        min = 0,
    ) # type: ignore
    
    leggings_trim_colour : bpy.props.FloatVectorProperty(
        name="", 
        subtype='COLOR', 
        size = 4,
        default=[1, 1, 1, 1],
        max = 1,
        min = 0,
    ) # type: ignore
    
    boots_trim_colour : bpy.props.FloatVectorProperty(
        name="", 
        subtype='COLOR', 
        size = 4,
        default=[1, 1, 1, 1],
        max = 1,
        min = 0,
    ) # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        column = self.layout.column()
        column.row().prop(self, "armor_type", expand = True)

        pcoll = icons.mcam_icons[icons.PCOLL_DLC_ID]
        if self.armor_type == "default":
            utils.UI_Utils.spacer(column, 0.3)

            icon = {
                'helmet' : pcoll["Thomas_Rig_Legacy:helmet_iron"].icon_id,
                'chestplate' : pcoll["Thomas_Rig_Legacy:chestplate_iron"].icon_id,
                'leggings' : pcoll["Thomas_Rig_Legacy:leggings_iron"].icon_id,
                'boots' : pcoll["Thomas_Rig_Legacy:boots_iron"].icon_id
            }

            for element in self.armor_parts:
                row = column.row()
                row.label(text="", icon_value=icon.get(element))
                row.prop(self, element)
                if getattr(self, element):
                    # material
                    row.prop(self, element + "_material")

                    #trims
                    row = row.row()
                    row.prop(self, element + "_trim")
                    row = row.row()
                    row.enabled = (getattr(self, f"{element}_trim") != 'None')
                    row.prop(self, element + "_trim_colour")
        else:
            column.template_icon_view(context.window_manager.thomas_rig_legacy, "custom_armor")
            
            utils.UI_Utils.spacer(column, 0.3)
            column.prop(self, "helmet")
            column.prop(self, "chestplate")
            column.prop(self, "leggings")
            if bpy.context.window_manager.thomas_rig_legacy.custom_armor[:-4] in {'Scuba'}:
                column.prop(self, "boots")

    def execute(self, context):
        try:
            mode = bpy.context.object.mode
        except:
            mode = False

        rig = utils.get_rig()
        bpy.context.view_layer.objects.active = rig
        if self.armor_type == "default":
            for piece in self.armor_parts:
                if getattr(self, piece):
                    # default armor
                    bpy.context.view_layer.objects.active = rig
                    item = utils.ThomasRigAddArmor.add_default_armor(self, piece)

                    # default trim
                    part = f'{piece}_trim'
                    if  getattr(self, part) != 'None':
                        utils.ThomasRigAddArmor.add_trims(self, piece, item)
                        utils.ThomasRigBakeArmor.adjust_material(item)
                    else:
                        utils.ThomasRigBakeArmor.delete_nodes_no_trim(item)
                    if getattr(self, f"{piece}_material") == 'leather':
                        utils.ThomasRigBakeArmor.add_nodes_leather(item)
                    utils.ThomasRigBakeArmor.remove_alpha_faces(item)
        else:
            for piece in self.armor_parts:
                if getattr(self, piece):
                    utils.ThomasRigAddArmor.add_custom_armor(self, piece)

        bpy.ops.object.select_all (action='DESELECT')
        bpy.context.view_layer.objects.active = rig
        if mode:
            bpy.ops.object.mode_set(mode=mode, toggle=False)
        
        # force update no face mode
        rig.data.update_tag()
        return {'FINISHED'}


class THOMAS_RIG_TOOL_PARENT(Operator):
    bl_idname = "thomasriglegacy.parenttool"
    bl_label = "parent"
    bl_options = {'REGISTER', 'UNDO'}

    arm_side : bpy.props.EnumProperty(
        default = 'wrist.R',
        items = [('wrist.R', 'wrist.R', ''),
            ('wrist.L', 'wrist.L', '')
            ]) # type: ignore
    
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects) > 1
    
    def draw(self, context):
        self.layout.row().prop(self, "arm_side", expand = True)
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context: Context):
        rig = utils.get_rig()
        item = context.selected_objects[1]

        constraint = item.constraints.new(type="CHILD_OF")
        constraint.target = rig
        constraint.subtarget = self.arm_side
        return {'FINISHED'}
    

class ThomasRigLegacyAppendRigBase(Operator):
    bl_options = {'REGISTER', 'UNDO'}
    append_type:str = ""

    @classmethod
    def poll(cls, context):
        try:
            misc = utils.get_rig().pose.bones["Misc_Properties"]
            return (misc[cls.append_type] is None)
        except (AttributeError, KeyError, TypeError):
            return False
    
    def execute(self, context):
        thomas_rig = utils.get_rig()
        bpy.context.view_layer.objects.active = thomas_rig
        # appending
        directory = os.path.join(os.path.dirname(os.path.realpath(__file__)), "armor")
        file = os.path.join(directory, f"{self.append_type}.blend")
        directory = os.path.join(file, "Collection")
        filepath = os.path.join(directory, self.append_type.capitalize())
        bpy.context.view_layer.active_layer_collection =\
            bpy.context.view_layer.layer_collection.children[thomas_rig.users_collection[0].name]
        bpy.ops.wm.append(
            filepath=filepath,
            filename=self.append_type.capitalize(),
            directory=directory,
            link=False,
            active_collection=True)
        
        # merging
        appended_items = bpy.context.selected_objects[0].children
        object = appended_items[0]

        thomas_rig.select_set(True)            
        bpy.ops.object.join()
        bpy.ops.object.select_all (action='DESELECT')

        # add correct armature target for append_type
        if self.append_type == 'cape':
            lattice = appended_items[1]
            lattice.modifiers[0].object = thomas_rig
        else:
            object.modifiers[0].object = thomas_rig

        # parenting append_type bone
        bpy.ops.object.mode_set (mode='EDIT', toggle=False)
        thomas_rig.data.edit_bones[f'{self.append_type.capitalize()}_Main'].parent = thomas_rig.data.edit_bones['Upper_Body']
        bpy.ops.object.mode_set (mode='POSE', toggle=False)

        # register append_type to rig
        thomas_rig.pose.bones["Misc_Properties"][self.append_type] = object.users_collection[0]
        return {'FINISHED'}


class THOMAS_RIG_LEGACY_APPEND_CAPE(ThomasRigLegacyAppendRigBase):
    bl_idname = "thomasriglegacy.appendcape"
    bl_label = "append cape"
    append_type = "cape"


class THOMAS_RIG_LEGACY_APPEND_ELYTRA(ThomasRigLegacyAppendRigBase):
    bl_idname = "thomasriglegacy.appendelytra"
    bl_label = "append elytra"
    append_type = "elytra"
    

class ThomasRigLegacyRemoveRigBase(bpy.types.Operator):
    bl_options = {'REGISTER', 'UNDO'}
    append_type:str = ""

    @classmethod
    def poll(cls, context):
        try:            
            misc = utils.get_rig().pose.bones["Misc_Properties"]
            return (misc[cls.append_type] is not None)
        except (AttributeError, KeyError, TypeError):
            return False
    
    def execute(self, context):
        thomas_rig = utils.get_rig()
        bpy.context.view_layer.objects.active = thomas_rig

        # remove objects and material
        collection = thomas_rig.pose.bones["Misc_Properties"][self.append_type]
        for obj in collection.objects:
            if obj.type == 'MESH' and obj.material_slots:
                material = obj.material_slots[0].material
                if material:
                    break

        image = material.node_tree.nodes['Image Texture'].image
        bpy.data.images.remove(image)
        bpy.data.materials.remove(material)
        bpy.data.collections.remove(collection)

        # removing bones
        bpy.ops.object.mode_set (mode='EDIT', toggle=False)
        edit_bones = thomas_rig.data.edit_bones
        bone_names = self.get_bone_names()
        bones = [edit_bones[bone] for bone in bone_names if bone in edit_bones]
        for bone in bones:
            edit_bones.remove(bone)
        bpy.ops.object.mode_set (mode='POSE', toggle=False)
        
        # unregister append_type 
        thomas_rig.pose.bones["Misc_Properties"][self.append_type] = None
        return {'FINISHED'}

    def get_bone_names(self):
        return []


class THOMAS_RIG_LEGACY_REMOVE_CAPE(ThomasRigLegacyRemoveRigBase):
    bl_idname = "thomasriglegacy.removecape"
    bl_label = "remove cape"
    append_type = "cape"

    def get_bone_names(self):
        return ["Cape_Main", "Cape_Bendy", "Cape_Controller"]


class THOMAS_RIG_LEGACY_REMOVE_ELYTRA(ThomasRigLegacyRemoveRigBase):
    bl_idname = "thomasriglegacy.removeelytra"
    bl_label = "remove elytra"
    append_type = "elytra"

    def get_bone_names(self):
        return ["Elytra_Main",
                "Elytra_1.R", "Elytra_2.R", "Elytra_3.R", "Elytra_4.R", "Elytra_5.R", "Elytra_6.R", "Elytra_7.R",
                "Elytra_1.L", "Elytra_2.L", "Elytra_3.L", "Elytra_4.L", "Elytra_5.L", "Elytra_6.L", "Elytra_7.L"]


class THOMAS_RIG_LEGACY_APPEND_MISC(bpy.types.Operator):
    bl_options = {'REGISTER', 'UNDO'}
    bl_idname = "thomasriglegacy.appendmisc"
    bl_label = "append misc"

    def execute(self, context):
        misc = bpy.context.window_manager.thomas_rig_legacy.misc[:-4]
        utils.ThomasRigAddMisc(misc)
        return {'FINISHED'}

    
def register():
    bpy.utils.register_class(THOMAS_RIG_TAB_OT_SET)
    bpy.utils.register_class(THOMAS_RIG_ASSETS_ARMOR_TAB_OT_SET)
    bpy.utils.register_class(THOMAS_RIG_IMG_PACK)
    bpy.utils.register_class(THOMAS_RIG_SKIN_DOWNLOAD)
    bpy.utils.register_class(THOMAS_RIG_IMAGERELOAD)
    bpy.utils.register_class(THOMAS_RIG_ARMOR_ADD)
    bpy.utils.register_class(THOMAS_RIG_TOOL_PARENT)
    bpy.utils.register_class(THOMAS_RIG_LEGACY_APPEND_CAPE)
    bpy.utils.register_class(THOMAS_RIG_LEGACY_REMOVE_CAPE)
    bpy.utils.register_class(THOMAS_RIG_LEGACY_APPEND_ELYTRA)
    bpy.utils.register_class(THOMAS_RIG_LEGACY_REMOVE_ELYTRA)
    bpy.utils.register_class(THOMAS_RIG_LEGACY_APPEND_MISC)

def unregister():
    bpy.utils.unregister_class(THOMAS_RIG_LEGACY_APPEND_MISC)
    bpy.utils.unregister_class(THOMAS_RIG_LEGACY_REMOVE_ELYTRA)
    bpy.utils.unregister_class(THOMAS_RIG_LEGACY_APPEND_ELYTRA)
    bpy.utils.unregister_class(THOMAS_RIG_LEGACY_REMOVE_CAPE)
    bpy.utils.unregister_class(THOMAS_RIG_LEGACY_APPEND_CAPE)
    bpy.utils.unregister_class(THOMAS_RIG_TOOL_PARENT)
    bpy.utils.unregister_class(THOMAS_RIG_ARMOR_ADD)
    bpy.utils.unregister_class(THOMAS_RIG_IMAGERELOAD)
    bpy.utils.unregister_class(THOMAS_RIG_SKIN_DOWNLOAD)
    bpy.utils.unregister_class(THOMAS_RIG_IMG_PACK)
    bpy.utils.unregister_class(THOMAS_RIG_ASSETS_ARMOR_TAB_OT_SET)
    bpy.utils.unregister_class(THOMAS_RIG_TAB_OT_SET)